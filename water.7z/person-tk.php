<? $page='我的退款-退款维权-个人中心'; include('inc/header.php') ?>

  <div class="main-person container">
    <?php include('inc/nav-pills.php'); ?>
    <div class="row">
      <div class="col-sm-2 left-side person-left-side">
         <?php include('inc/person-nav.php'); ?>
      </div>
      <div class="col-sm-10 person-right-side person-right-side-tk">
        <ul class="person-tabs nav nav-tabs">
          <li role="presentation" class="active"><a href="person-tk.php">我的退款</a></li>
        </ul>

        <div class="col-xs-12 col-table">
          <div class="person-order-hd">
            <span class="sp1">项目</span>
            <span class="sp2">状态</span>
            <span class="sp3">操作</span>
          </div>

          <div class="preson-order-item first">
            <div class="d1">
              <div class="s fl"><a href="#"><img src="http://i2.s2.dpfile.com/pc/mc/113f268f16bcbb72e4cbb519cfa6e99e(246c184)/thumb.jpg" alt="" width="85" height="53"></a></div>
              <div class="msg">
                <h4><a href="javascript:void(0);">九毛九山西手工面:代金券</a></h4>
                <p class="p1">订单号：733366010</p> 
              </div>
            </div>
            <div class="d2 d2-1"><span class="sp1">状态:</span><span class="sp2">退款中</span></div>
            <div class="d2 control">
              <a href="#" class="btn btn-default">取消退款</a>
            </div>
          </div>

          <div class="preson-order-item">
            <div class="d1">
              <div class="s fl"><a href="#"><img src="http://i2.s2.dpfile.com/pc/mc/113f268f16bcbb72e4cbb519cfa6e99e(246c184)/thumb.jpg" alt="" width="85" height="53"></a></div>
              <div class="msg">
                <h4><a href="javascript:void(0);">九毛九山西手工面:代金券</a></h4>
                <p class="p1">订单号：733366010</p> 
              </div>
            </div>
            <div class="d2 d2-1"><span class="sp1">状态:</span><span class="sp2">退款中</span></div>
            <div class="d2 control">
              <a href="#" class="btn btn-default">取消退款</a>
            </div>
          </div>

          <div class="preson-order-item">
            <div class="d1">
              <div class="s fl"><a href="#"><img src="http://i2.s2.dpfile.com/pc/mc/113f268f16bcbb72e4cbb519cfa6e99e(246c184)/thumb.jpg" alt="" width="85" height="53"></a></div>
              <div class="msg">
                <h4><a href="javascript:void(0);">九毛九山西手工面:代金券</a></h4>
                <p class="p1">订单号：733366010</p> 
              </div>
            </div>
            <div class="d2 d2-1"><span class="sp1">状态:</span><span class="sp2">退款中</span></div>
            <div class="d2 control">
              <a href="#" class="btn btn-default">取消退款</a>
            </div>
          </div>



          <nav class="pagenation-nav">
            <ul class="pagination">
              <li>
                <a href="#" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <li><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">4</a></li>
              <li><a href="#">5</a></li>
              <li>
                <a href="#" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            </ul>
          </nav>

        </div>
      </div>
    </div>



  </div><!-- /中间 -->
  
<?php include('inc/footer.php'); ?>
