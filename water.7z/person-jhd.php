<? $page='聚活动-我的订单-个人中心'; include('inc/header.php') ?>

  <div class="main-person container">
    <?php include('inc/nav-pills.php'); ?>

    <div class="row">
      <div class="col-sm-2 left-side person-left-side">
          <?php include('inc/person-nav.php'); ?>
      </div>
      <div class="col-sm-10 person-right-side">
          <?php include('inc/person-nav-dd.php'); ?>  

        <div class="col-xs-12 col-table">
          <div class="choose-bar">
            <a class="del fr" href="#">删除订单</a>
            <label class="label1"><input type="checkbox" name="" id="" />全选</label>
            <a href="#" class="a1 active">代付款</a>
            <a href="#" class="a2">已付款</a>
            <a href="#" class="a3">退款</a>
          </div>

          <div class="person-order-hd">
            <span class="sp1">订单信息</span>
            <span class="sp2">下单时间</span>
            <span class="sp3">数量</span>
            <span class="sp4">金额</span>
            <span class="sp5">交易状态</span>
            <span class="sp6">操作</span>
          </div>

          <div class="preson-order-item">
            <div class="d1">
              <input class="fl" type="checkbox" name="" id="" />
              <div class="img fl"><img src="http://i1.s2.dpfile.com/pc/mc/da483cfbb92dbf8b40f3b819c1745a52(246c184)/thumb.jpg" alt="" width="85" height="53"></div>
              <div class="msg">
                <h4><a href="javascript:void(0);">九毛九山西手工面:代金券</a></h4>
                <p class="p1">订单号：733366010</p> 
                <p class="p1">过期时间：2015-12-31</p> 
              </div>
            </div>
            <div class="d2 d2-1"><span class="sp1">下单时间:</span>2015-07-26</div>
            <div class="d2 d2-1 d2-count"><span class="sp1">数量:</span> 1</div>
            <div class="d2 d2-1"><span class="sp1">金额:</span> ¥99.99</div>
            <div class="d2 d2-1"><span class="sp1">交易状态:</span> 等待付款</div>
            <div class="d2 control">
              <a href="#" class="btn btn-default">付款</a>
              <a href="#" class="btn btn-default">删除</a>
              <a href="#" class="btn btn-default">申请退款</a>
            </div>
          </div>

          <div class="preson-order-item">
            <div class="d1">
              <input class="fl" type="checkbox" name="" id="" />
              <div class="img fl"><img src="http://i1.s2.dpfile.com/pc/mc/da483cfbb92dbf8b40f3b819c1745a52(246c184)/thumb.jpg" alt="" width="85" height="53"></div>
              <div class="msg">
                <h4><a href="javascript:void(0);">九毛九山西手工面:代金券</a></h4>
                <p class="p1">订单号：733366010</p> 
                <p class="p1">过期时间：2015-12-31</p> 
              </div>
            </div>
            <div class="d2 d2-1"><span class="sp1">下单时间:</span>2015-07-26</div>
            <div class="d2 d2-1 d2-count"><span class="sp1">数量:</span> 1</div>
            <div class="d2 d2-1"><span class="sp1">金额:</span> ¥99.99</div>
            <div class="d2 d2-1"><span class="sp1">交易状态:</span> 等待付款</div>
            <div class="d2 control">
              <a href="#" class="btn btn-default">付款</a>
              <a href="#" class="btn btn-default">删除</a>
              <a href="#" class="btn btn-default">申请退款</a>
            </div>
          </div>

          <div class="preson-order-item">
            <div class="d1">
              <input class="fl" type="checkbox" name="" id="" />
              <div class="img fl"><img src="http://i1.s2.dpfile.com/pc/mc/da483cfbb92dbf8b40f3b819c1745a52(246c184)/thumb.jpg" alt="" width="85" height="53"></div>
              <div class="msg">
                <h4><a href="javascript:void(0);">九毛九山西手工面:代金券</a></h4>
                <p class="p1">订单号：733366010</p> 
                <p class="p1">过期时间：2015-12-31</p> 
              </div>
            </div>
            <div class="d2 d2-1"><span class="sp1">下单时间:</span>2015-07-26</div>
            <div class="d2 d2-1 d2-count"><span class="sp1">数量:</span> 1</div>
            <div class="d2 d2-1"><span class="sp1">金额:</span> ¥99.99</div>
            <div class="d2 d2-1"><span class="sp1">交易状态:</span> 等待付款</div>
            <div class="d2 control">
              <a href="#" class="btn btn-default">付款</a>
              <a href="#" class="btn btn-default">删除</a>
              <a href="#" class="btn btn-default">申请退款</a>
            </div>
          </div>

          <div class="preson-order-item">
            <div class="d1">
              <input class="fl" type="checkbox" name="" id="" />
              <div class="img fl"><img src="http://i1.s2.dpfile.com/pc/mc/da483cfbb92dbf8b40f3b819c1745a52(246c184)/thumb.jpg" alt="" width="85" height="53"></div>
              <div class="msg">
                <h4><a href="javascript:void(0);">九毛九山西手工面:代金券</a></h4>
                <p class="p1">订单号：733366010</p> 
                <p class="p1">过期时间：2015-12-31</p> 
              </div>
            </div>
            <div class="d2 d2-1"><span class="sp1">下单时间:</span>2015-07-26</div>
            <div class="d2 d2-1 d2-count"><span class="sp1">数量:</span> 1</div>
            <div class="d2 d2-1"><span class="sp1">金额:</span> ¥99.99</div>
            <div class="d2 d2-1"><span class="sp1">交易状态:</span> 等待付款</div>
            <div class="d2 control">
              <a href="#" class="btn btn-default">付款</a>
              <a href="#" class="btn btn-default">删除</a>
              <a href="#" class="btn btn-default">申请退款</a>
            </div>
          </div>

          <nav class="pagenation-nav">
            <ul class="pagination">
              <li>
                <a href="#" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <li><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">4</a></li>
              <li><a href="#">5</a></li>
              <li>
                <a href="#" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
            </ul>
          </nav>

        </div>
      </div>
    </div>



  </div><!-- /中间 -->
  
  <?php include('inc/footer.php'); ?>
