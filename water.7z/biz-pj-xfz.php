<? $page='消费者评价-验证管理-我是商家'; include('inc/header.php') ?>

  <div class="main-person container">
    <?php include('inc/nav-pills.php'); ?>
      <div class="row">
        <div class="col-sm-2 left-side person-left-side">
          <?php include('inc/biz-nav.php'); ?>
        </div>
        <div class="col-sm-10 person-right-side person-right-side-jf">
          <?php include('inc/biz-nav-pl.php'); ?>
            <div class=" col-xs-12 col-table biz-val-fypj-col">
              <form action="">
                <div class="form-group-choose form-group">
                  <label for="">选择团购：</label>
                  <select name="#">
                    <option>轩辕古法沐足城团购信息2</option>
                    <option>轩辕古法沐足城团购信息2</option>
                  </select>
                </div>
                <div class="form-group-state form-group">
                  <p class="state-p1">
                    <span class="sp1">团购状态：未过期销售</span>
                    <span class="sp1">时间：2015-06-23至2015-12-31</span>
                    <span class="sp1">团购券有效日期：2015-06-16至2015-12-31</span>
                  </p>
                </div>
              </form>

              <div class="box-pj">
                <!-- <div class="count-bk none"> 
            <p class="count-bk-row1">平均5分</p>
            <div class="count-bk-item">
              <span class="star"><span class="sp1"></span></span>
              <span class="pro"><span class="sp1"></span></span>
              <span class="nub">1封</span>
            </div>
            <div class="count-bk-item">
              <span class="star"><span class="sp1"></span></span>
              <span class="pro"><span class="sp1"></span></span>
              <span class="nub">1封</span>
            </div>
            <div class="count-bk-item">
              <span class="star"><span class="sp1"></span></span>
              <span class="pro"><span class="sp1"></span></span>
              <span class="nub">1封</span>
            </div>
            <div class="count-bk-item">
              <span class="star"><span class="sp1"></span></span>
              <span class="pro"><span class="sp1"></span></span>
              <span class="nub">1封</span>
            </div>
            <div class="count-bk-item">
              <span class="star"><span class="sp1"></span></span>
              <span class="pro"><span class="sp1"></span></span>
              <span class="nub">1封</span>
            </div>
          -->
                <h3 class="box-pj-hd"><span class="fr">共有<span class="sp1">3</span>人评价</span>用户评论</h3>
                <div class="media">
                  <div class="media-left">
                    <a href="#">
                      <img class="media-object" src="http://i1.dpfile.com/pc/acef3e72b913fff270f1ec60bac6a81f(48c48)/thumb.jpg" alt="...">
                    </a>
                  </div>
                  <div class="media-body">
                    <div class="top-row clearfix">
                      <span class="name fl">f***</span>
                      <span class="date fr">评价时间：2015-08-07 01:24:08</span>
                    </div>
                    <div class="info-pl">
                      <div class="clearfix">
                        <div class="myd fl">满意度：<span class="star"><span class="sp1" style="width:38%;"></span></span>
                        </div>
                        <div class="fd-name fr">分店：轩辕古法沐足城</div>
                      </div>
                      <div class="info-pl-sf">
                        服务态度都很好 手法也不错 还会再来哦
                      </div>
                    </div>
                  </div>
                </div>

                <div class="media">
                  <div class="media-left">
                    <a href="#">
                      <img class="media-object" src="http://i1.dpfile.com/pc/acef3e72b913fff270f1ec60bac6a81f(48c48)/thumb.jpg" alt="...">
                    </a>
                  </div>
                  <div class="media-body">
                    <div class="top-row clearfix">
                      <span class="name fl">f***</span>
                      <span class="date fr">评价时间：2015-08-07 01:24:08</span>
                    </div>
                    <div class="info-pl">
                      <div class="clearfix">
                        <div class="myd fl">满意度：<span class="star"><span class="sp1" style="width:100%;"></span></span>
                        </div>
                        <div class="fd-name fr">分店：轩辕古法沐足城</div>
                      </div>
                      <div class="info-pl-sf">
                        服务态度都很好 手法也不错 还会再来哦
                      </div>
                    </div>
                  </div>
                </div>

                <div class="media">
                  <div class="media-left">
                    <a href="#">
                      <img class="media-object" src="http://i1.dpfile.com/pc/acef3e72b913fff270f1ec60bac6a81f(48c48)/thumb.jpg" alt="...">
                    </a>
                  </div>
                  <div class="media-body">
                    <div class="top-row clearfix">
                      <span class="name fl">f***</span>
                      <span class="date fr">评价时间：2015-08-07 01:24:08</span>
                    </div>
                    <div class="info-pl">
                      <div class="clearfix">
                        <div class="myd fl">满意度：<span class="star"><span class="sp1" style="width:58%;"></span></span>
                        </div>
                        <div class="fd-name fr">分店：轩辕古法沐足城</div>
                      </div>
                      <div class="info-pl-s">
                        服务态度都很好 手法也不错 还会再来哦
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>


        </div>

      </div>
  </div>

  <!-- /中间 -->


  <?php include('inc/footer.php'); ?>
