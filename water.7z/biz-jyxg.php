<? $page='经营效果(数据统计及图表展示)-团购项目-我是商家'; include('inc/header.php') ?>

  <div class="main-person container">
    <?php include('inc/nav-pills.php'); ?>
      <div class="row">
        <div class="col-sm-2 left-side person-left-side">
          <?php include('inc/biz-nav.php'); ?>
        </div>
        <div class="col-sm-10 person-right-side person-right-side-jf">
          <?php include('inc/biz-nav-pro.php'); ?>          
          <div class="fds col-xs-12 col-table biz-scsh-col">
            <div class="fdsf jyxg-flash">
              (数据统计及图表展示)
            </div>
          </div>
        </div>
      </div>
  </div>

  <!-- /中间 -->

  <?php include('inc/footer.php'); ?>
