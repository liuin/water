<? $page='消息中心-团购项目-我是商家'; include('inc/header.php') ?>

  <div class="main-person container">
    <?php include('inc/nav-pills.php'); ?>
      <div class="row">
        <div class="col-sm-2 left-side person-left-side">
          <?php include('inc/biz-nav.php'); ?>
        </div>
        <div class="col-sm-10 person-right-side person-right-side-jf">
          <ul class="person-tabs nav nav-tabs">
            <li role="presentation" class="active">
              <a href="biz-scsh.php">消息中心</a>
            </li>
          </ul>
          <div class="col-xs-12 col-table biz-msg-col">
            <div class="biz-msg-item-xt biz-msg-item">
              <h3>系统消息：</h3>
              <div class="txt">
                您好：的范德萨发生反对第三方的是否是
              </div>
            </div>
            <div class="biz-msg-item">
              <h3>客户消息：</h3>
              <div class="txt">
                您好：的范德萨发生反对第三方的是否是XXXXXX
              </div>
            </div>
          </div>
          <!-- 消息中心 -->
        </div>
      </div>
  </div> 

  <!-- /中间 -->

  <?php include('inc/footer.php'); ?>
