<? $page='提款管理-团购项目-我是商家'; include('inc/header.php') ?>

  <div class="main-person container">
    <?php include('inc/nav-pills.php'); ?>
      <div class="row">
        <div class="col-sm-2 left-side person-left-side">
          <?php include('inc/biz-nav.php'); ?>
        </div>
        <div class="col-sm-10 person-right-side person-right-side-jf">
          <ul class="person-tabs nav nav-tabs">
            <li role="presentation" class="active">
              <a href="biz-scsh.php">提款管理</a>
            </li>
          </ul>
          <div class="col-xs-12 col-table biz-tkgl-col">
            <div class="tkgl-box">
              欠数据提供
            </div>
          </div>
          <!-- 消息中心 -->
        </div>
      </div>
  </div>

  <!-- /中间 -->

  <?php include('inc/footer.php'); ?>
