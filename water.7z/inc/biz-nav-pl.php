<ul class="person-tabs nav nav-tabs">
  <li <?php if(isset($page)&&strstr($page,'消费者评价')){echo 'class="active"';} ?> role="presentation"><a href="biz-pj-xfz.php">消费者评价</a></li>
  <li <?php if(isset($page)&&strstr($page,'门店评价详情')){echo 'class="active"';} ?> role="presentation"><a href="biz-pj-md.php">门店评价详情</a></li>
</ul>