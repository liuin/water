<!DOCTYPE html>
<html><head><script src="http://t.dianping.com/jsonp/hot_sale_deals?cityId=4&amp;reqid=0a016712-14aab0156d8-216759&amp;callback=DP._JSONPRequest._1" async=""></script><script src="http://j3.s2.dpfile.com/x_x/version.min.v1419932922965.js" async=""></script>
<meta charset="UTF-8">
<base href="http://www.dianping.com/">
<script>(function(n){var e;e="http://114.80.165.63/broker-service/api/js",n.onerror=function(n,o,r){var i=encodeURIComponent,t=+new Date();(new Image).src=e+"?error="+i(n)+"&file="+i(o)+"&line="+i(r)+"&timestamp="+t}})(window);</script>
<title>广州美食,广州餐厅餐饮,广州团购,广州生活,优惠券-大众点评网</title>

<link rel="Shortcut Icon" href="http://j1.s2.dpfile.com/s/res/favicon.5ff777c11d7833e57e01c9d192b7e427.ico" type="image/x-icon">
<link rel="apple-touch-icon" href="http://j2.s2.dpfile.com/s/res/app-touch-icon.89213f53ed66e1693e4b6aeedd355349.png">
<link rel="apple-touch-icon" sizes="76x76" href="http://j2.s2.dpfile.com/s/res/app-touch-icon-76x76.6399ce382f3e0584a6b07599cbeb3bcb.png">
<link rel="apple-touch-icon" sizes="120x120" href="http://j2.s2.dpfile.com/s/res/app-touch-icon-120x120.067844b8518f076b154dcf793a46a0a5.png">
<link rel="apple-touch-icon" sizes="152x152" href="http://j2.s2.dpfile.com/s/res/app-touch-icon-152x152.ee6d0c24fc2de0f9a62b6cc9e6720393.png">

<link rel="stylesheet" href="http://j2.s2.dpfile.com/s/c/app/main/base-old.min.cec1f2f5a11bcd497ff116f4567ca3cf.css" type="text/css">
<link rel="stylesheet" href="http://j1.s2.dpfile.com/s/c/app/main/index-header/index.min.c370a0d3560d123140518b2f848dc0d3.css" type="text/css">
<link rel="stylesheet" href="http://j1.s2.dpfile.com/s/c/app/main/index-header/footer.min.b89d87532d5fe16706082281d2eec4cc.css" type="text/css">


<link rel="stylesheet" href="http://j1.s2.dpfile.com/s/c/app/index/common.min.55c7c4bf9136b6d6f3e16b6f11810c11.css" type="text/css">
        <link rel="stylesheet" href="http://j1.s2.dpfile.com/s/c/app/booking/booking.plugin.min.984b6d251dd470d6c4b93205f68de7a1.css">
        <script>
            var __loaderCombo = {
                'http://j3.s2.dpfile.com/combos/~s~j~app~promo~placeholder.min.js,~s~j~app~main~placeholder.min.js,~s~j~app~main~mbox.min.js,~s~j~app~promo~mbox.min.js,~s~j~app~main~biz~mkt.min.js,~s~j~app~main~bulletin.min.js,~s~j~app~main~mkt.min.js,~s~j~app~main~tg-content.min.js,~lib~1.0~storage~local.min.js,~lib~1.0~storage~local-expire.min.js,~lib~1.0~mvp~tpl.min.js,~lib~1.0~dom~dimension.min.js,~lib~1.0~suggest.min.js,~lib~1.0~io~ajax.min.js,~lib~1.0~io~jsonp.min.js,~lib~1.0~util~cookie.min.js,~lib~1.0~util~queue.min.js,~lib~1.0~util~json.min.js,~lib~1.0~event~multi.min.js,~lib~1.0~event~live.min.js,~lib~1.0~switch~core.min.js,~lib~1.0~switch~conf.min.js,~lib~1.0~switch~tabswitch.min.js,~lib~1.0~switch~carousel.min.js,~lib~1.0~switch~autoplay.min.js,~lib~1.0~fx~tween.min.js,~lib~1.0~fx~easing.min.js,~lib~1.0~fx~css.min.js,~lib~1.0~fx~core.min.js/8b8f8f355aeac43833c8c3ce9c141175,8b8f8f355aeac43833c8c3ce9c141175,e57178e2684d3f7b36e0cc50abdeb01a,755028a19cabfa057e417a7718ededc2,247d46ca8b1f52040664b849eade381a,350a5fe49af6ab08f1307d8c26ff343d,731eecb58192880d577d7600054b080d,fb0922bab163860af76cebf35fcf2ac6,8602861a2c191a9959f183138c097790,463c113fe9572f1ce5acbbff67710250,681c5b24a9a215968286adb35ea9a1b4,f12f839642deedcc2ef8e2235f146031,ea3b7ce0b29712205015c66468da7d85,85362489ccceac3fc3303ec569dd2b74,08440f9945a0f99cbbcadce7d5b140bf,afe6182c4f181e2d419ebec8c0026a69,f000da58a69731e4d966b79f319a973f,e54951fd409a1f2680a457e395b90dc1,7820a44330e04c9718005bfa97e80bc8,649a5074e678c2ca97609ade4c68ad5f,577271a07070095dc9c4398c1056b735,643e258aedf04b4bd5919ded8263191b,9aedd735203bac14d3da0420f278ee8b,4f1cd478d938e4ece4b5a6cb53b83b02,bb9c320f46054d5277a3aea90fd37747,97c9a39afa1a5d4bee3a0cfe8d5989f3,7e42281ab447ebdb115a133cc38cf03d,183b08c14447afc24ea8435a7500e020,d322a81f5d82047eb2b98912fe53c609.js' : [
                    '/s/j/app/promo/placeholder.js',
                    '/s/j/app/main/placeholder.js',
                    '/s/j/app/main/mbox.js',
                    '/s/j/app/promo/mbox.js',
                    '/s/j/app/main/biz/mkt.js',
                    '/s/j/app/main/bulletin.js',
                    '/s/j/app/main/mkt.js',
                    '/s/j/app/main/tg-content.js',
                    '/lib/1.0/storage/local.js',
                    '/lib/1.0/storage/local-expire.js',
                    '/lib/1.0/mvp/tpl.js',
                    '/lib/1.0/dom/dimension.js',
                    '/lib/1.0/suggest.js',
                    '/lib/1.0/io/ajax.js',
                    '/lib/1.0/io/jsonp.js',
                    '/lib/1.0/util/cookie.js',
                    '/lib/1.0/util/queue.js',
                    '/lib/1.0/util/json.js',
                    '/lib/1.0/event/multi.js',
                    '/lib/1.0/event/live.js',
                    '/lib/1.0/switch/core.js',
                    '/lib/1.0/switch/conf.js',
                    '/lib/1.0/switch/tabswitch.js',
                    '/lib/1.0/switch/carousel.js',
                    '/lib/1.0/switch/autoplay.js',
                    '/lib/1.0/fx/tween.js',
                    '/lib/1.0/fx/easing.js',
                    '/lib/1.0/fx/css.js',
                    '/lib/1.0/fx/core.js'
                ],
                'http://j2.s2.dpfile.com/combos/~s~j~app~index~city.min.js,~s~j~app~main~datepicker~superdatepicker.min.js,~s~j~app~main~datepicker~supercalendar.min.js,~s~j~app~main~datepicker~calendarmodel.min.js/10e567965240627f31adeb03a0b5bb9d,d401bfe3cb080f56d3dd5477496085ce,d8f8da0738a40c79c6a6033059fc4f8a,f06dc4c4bf7930ab9e2d04b347c43684.js' : [
                    '/s/j/app/index/city.js',
                    '/s/j/app/main/datepicker/superdatepicker.js',
                    '/s/j/app/main/datepicker/supercalendar.js',
                    '/s/j/app/main/datepicker/calendarmodel.js'
                ],
                'http://j3.s2.dpfile.com/combos/~s~j~app~booking~common~datepicker~superdatepicker.min.js,~s~j~app~booking~common~datepicker~supercalendar.min.js,~s~j~app~booking~common~datepicker~calendarmodel.min.js,~s~j~app~booking~mainbookingplugin.min.js,~s~j~app~booking~reserveregion.min.js,~s~j~app~activity~vdperweekstarplugin.min.js,~s~j~app~hotel~index~hotel-shortcut.min.js,~s~j~app~main~app-2d.min.js/b3e3cb309221bc1b22a8840110270109,b5eee190bf95f12f9de6d7c22ac69122,f06dc4c4bf7930ab9e2d04b347c43684,1b1894cf4901ba0a3d9303a43b2977d4,9aa72d14ba3ca95811990f050e1bb11c,7fd1b11eab660e758b0604e60ee90336,ab65fdf8fa47a417d9e87712210238df,eea8ab135c6a3be13b563abf9f3b706c.js' : [
                    '/s/j/app/booking/common/datepicker/superdatepicker.js',
                    '/s/j/app/booking/common/datepicker/supercalendar.js',
                    '/s/j/app/booking/common/datepicker/calendarmodel.js',
                    '/s/j/app/booking/mainbookingplugin.js',
                    '/s/j/app/booking/reserveregion.js',
                    '/s/j/app/activity/vdperweekstarplugin.js',
                    '/s/j/app/hotel/index/hotel-shortcut.js',
                    '/s/j/app/main/app-2d.js'
                ]
            }
        </script>
  <meta name="Keywords" content="大众点评网,广州,优惠券,社区论坛,美食餐馆,住宿酒店,最佳餐厅,本周热门,口味最好餐厅,热门购物,热门休闲,天河城/体育中心,北京路,环市东,珠江新城,中山二三路/东山口"> <meta name="Description" content="根据合理的商区、地标和详细的商户分类系统，为你提供广州273632个餐饮美食、婚庆、住宿酒店、美容美发等消费场所，并通过海量亲身消费者的点评聚合，以各种评分、星级的标准让你选择。"> <meta http-equiv="mobile-agent" content="format=xhtml; http://m.dianping.com/default.aspx?c=4"> <meta http-equiv="mobile-agent" content="format=html5; url=http://m.dianping.com/guangzhou"> <!--[if IE 9]> <meta name="application-name" content="大众点评网_美食，生活，团购，优惠券" /> <meta name="msapplication-tooltip" content="大众点评网_美食，生活，团购，优惠券" /> <meta name="msapplication-task" content="name=找商户;action-uri=/search/category/4/0?utm_source=pinie9&utm_medium=web&utm_term=daohang&utm_content=search;icon-uri=http://j3.s2.dpfile.com/s/res/pintab/dp-tiny.ff990be86aefd5060695d128f11258d1.ico" /> <meta name="msapplication-task" content="name=点评团;action-uri=http://t.dianping.com?utm_source=pinie9&utm_medium=web&utm_term=daohang&utm_content=tuan;icon-uri=http://j3.s2.dpfile.com/s/res/pintab/dp-tiny.ff990be86aefd5060695d128f11258d1.ico" /> <meta name="msapplication-task" content="name=优惠券;action-uri=/info?utm_source=pinie9&utm_medium=web&utm_term=daohang&utm_content=promo;icon-uri=http://j3.s2.dpfile.com/s/res/pintab/dp-tiny.ff990be86aefd5060695d128f11258d1.ico" /> <meta name="msapplication-task" content="name=手机版;action-uri=http://q.dianping.com?utm_source=pinie9&utm_medium=web&utm_term=daohang&utm_content=qiandao;icon-uri=http://j3.s2.dpfile.com/s/res/pintab/dp-tiny.ff990be86aefd5060695d128f11258d1.ico" /> <meta name="msapplication-task" content="name=社区;action-uri=http://s.dianping.com?utm_source=pinie9&utm_medium=web&utm_term=daohang&utm_content=group;icon-uri=http://j3.s2.dpfile.com/s/res/pintab/dp-tiny.ff990be86aefd5060695d128f11258d1.ico" /> <meta name="msapplication-starturl" content="./?utm_source=pinie9&utm_medium=web&utm_term=home" /> <meta name="msapplication-navbutton-color" content="#ff9000" /> <link rel="shortcut icon" href="http://j1.s2.dpfile.com/s/res/pintab/favicon.84e3742c6cce5c6f80a44f1f6fe6d442.ico" type="image/x-icon" /> <![endif]--> <!-- concurrent --> <script type="text/javascript"> (function(){var g=["iPhone","Android","Windows Phone"],b="http://m.dianping.com",j="/guangzhou", e=window.location.pathname,f=false;for(var d=0,a;a=g[d];d++){if(navigator.userAgent.indexOf(a)!=-1){f=true;break}}function h(){location.href=b+j}function c(){if(document.referrer.indexOf(b)==0){document.cookie="vmod=pc;expires=0;"}return document.cookie.match(/vmod=pc/)}if(f){if(!c()){h()}}})(); </script> 
</head>
<style type="text/css">
  a {color:#06c;}
  .page-header .search-bar {border: 2px solid rgb(48, 152, 249);}
  .page-header .search-bar .search-btn {background-color: #3098f9;}
  .site-nav .container, .page-header .container, .main-nav .container, .main {width:1200px;}
  .page-header .search-bar input {width:535px;}
  .page-header .search-box {width:610px;}
</style>
<body id="top">

<style type="text/css">
.w1020 { width: 1200px;
  margin: 0 auto;}
.container-navbar {
 background: #f6f6f6;
}
.page-header .search-bar .search-btn:hover {background-color: #3098f9;}
.navbar-inverse .navbar-inner {

width: 1200px;
margin: 0 auto;
color: #4C4C4C;
line-height: 20px;
font-size: 12px;
}
.top_a {
color: #06c ;
line-height:30px;
}
.topblock { }
.page-header {}
.page-header .logo {background: transparent;}

</style>
<div class="topblock">
  <div class="container-navbar">
    <div class="navbar navbar-inverse">
      <div class="navbar-inner">
               <span class="top_span">您好，请</span>
               <a href="http://203.166.186.14/Login" class="top_a">登录</a>
               <a href="http://203.166.186.14/Register" class="top_a">免费注册</a>
        </div>
    </div>
  </div>
  <div id="page-header" class="page-header">
    <div class="container">
    <a onclick="pageTracker._trackPageview('dp_head_logo_guangzhou');" title="大众点评网" href="http://www.dianping.com" class="logo"><img src="http://localhost/my-temp/website/des-water/logo.png" alt="" /></a>
  <div class="search-box">
    <div class="search-bar">
      <input class="" id="G_s" x-webkit-speech="" x-webkit-grammar="builtin:translate" data-s-pattern="http://www.dianping.com/search/keyword/{0}/{1}_" data-s-epattern="http://www.dianping.com/search/category/{0}/{1}" data-s-cateid="0" data-s-cityid="4" data-s-chanid="999" type="text" placeholder="搜索商户名、地址、菜名、外卖等" autocomplete="off" onwebkitspeechchange="pageTracker._trackPageview('dp_head_kerword_voice_guangzhou');">
      <a class="search-btn J-search-btn" id="G_s-btn"><i class="icon i-search"></i></a>
    </div>
      <div class="hot-key"><a href="/search/keyword/4/0_酒吧">酒店</a><a href="/search/keyword/4/0_按摩">酒店</a><a href="/search/keyword/4/0_酒店">酒店</a><a href="/search/keyword/4/0_KTV">KTV</a><a href="/search/keyword/4/0_电影院">电影院</a></div>
  </div>
    <div class="area">
      <style type="text/css">
        .topbarul {float: right; font-size: 14px; line-height: 36px; margin-left: 22px; margin-top: 15px;}
        .topbarul li {float:left;}
        .topbarul a {display:inline-block;margin-right:10px; color:#4c4c4c;}
      </style>
    <ul class="topbarul">
      <li>
                      <a href="http://203.166.186.14/About">
                          <span class="id_1" data="关于联盟">地区:</span>
                         
                      </a>
                  </li>
                  <li>
                      <a href="http://203.166.186.14/About">
                          <span class="id_1" data="关于联盟" style=" color:#06c; font-weight:bold;">广州</span>
                          /
                      </a>
                  </li>
                  <li>
                      <a href="http://203.166.186.14/News">
                          <span class="id_2" data="新闻资讯">佛山</span>
                          /
                      </a>
                  </li>
                  <li>
                      <a href="http://203.166.186.14/Meeting">
                          <span class="id_3" data="会务活动">深圳</span>
                          /
                      </a>
                  </li>
                  <li>
                      <a href="http://203.166.186.14/Meeting">
                          <span class="id_3" data="会务活动">更多地区</span>
                         
                      </a>
                  </li>
                                      
              </ul>
    </div>
    </div>
  </div>
  <style type="text/css">
    /* nav */
  .v_nav_search{position: relative;z-index: 998;zoom:1;width:100%;min-width: 1100px;_width:expression(this.scrollWidth < 1100 ? "1100px" : "auto");}
  .v_nav{ height: 40px;width:100%;zoom:1;position:relative; background: #2577e3;}
  .v_nav .sub{width: 1200px;position: relative;margin: 0 auto;height: 40px;overflow: hidden;}
  .v_nav ul{width: 1200px;height: 40px;}
  .v_nav ul li{float: left;}
  .v_nav ul li a{display: block;height: 20px;line-height: 20px;padding: 10px 12px;color: #fff;font-size: 14px;font-family: "Microsoft Yahei";text-decoration: none;float: left;}
  .v_nav ul li.hover a,.v_nav ul li a:hover,.v_nav ul li.hover a.current,.v_nav ul li a.current{background:#fff;color: #06c;text-decoration: none;}
  .v_nav_sbox{width:100%;}
  .v_nofixed_nav{_top:expression(eval(0));border-bottom: 0px solid #3c9bd6;}
  .v_nofixed_nav .v_nav_sbox{background-color: #c70048; display:none;}
  .v_nav_sbox .v_nav_sbox_inner{width: 1100px;margin: 0 auto;height: 15px;position: relative;}
  .v_fixed_nav{position: fixed;top: 0;left: 0;width: 100%;_position:absolute;_top: expression(eval(document.documentElement.scrollTop));}
  .v_fixed_nav .v_nav_sbox .v_nav_sbox_inner{padding: 11px 0;height: 34px;width: 1100px;}
  .v_fixed_nav .v_nav_sbox{background-color: rgba(187,8,73,.9);}
  .v_nav_sbox .search_box{margin-top: 0;height: 34px;display: none;top: 10px;}
  .v_fixed_nav .search_box{display: block;}
  .v_nav_sbox .search_box .search form{height: 32px;}
  .v_nav_sbox  .search_box .v_select_box .v_sel_a,.v_nav_sbox  .search_box .v_select_box .v_sel_a:hover{height: 32px;line-height: 32px;background-position: 74px -21px;}
  .v_nav_sbox .search_box .v_select_box .now,.v_nav_sbox .search_box .v_select_box .now:hover{background-position: 74px 14px;}
  .v_nav_sbox .search_box .search .text{padding: 7px 0;}
  .v_nav_sbox .search_box .select{height: 32px;line-height: 32px;}
  .v_nav_sbox .search_box .select .icon{top: 12px;}
  .v_nav_sbox .search_box .select .select_pop{top: 32px;}
  .v_nav_sbox .search_box .suggest_key{top: 33px;}
  .v_nav_sbox .search_box .button {height: 34px;background-position: center -67px;}
  .v_nav_sbox .search .hot,.v_nav_sbox .search_box .search .search_btn{height: 34px;line-height: 34px;color: #fff;}
  .v_nav_sbox .search .hot,.v_nav_sbox .search .hot a{color: #fff;}
  .v_nav_sbox .search_box .search .label_search{height: 32px;line-height: 32px;}
  .v_nav_sbox .search_box .search .del-keywords{top: 8px;}
  </style>
  <div class="v_nav_search v_nofixed_nav" id="v_fixed_div">
      <div class="v_nav">
      <div class="sub">
      <ul>
                  <li><a name="nav2" target="_blank" href="http://www.dangdang.com/" class="current">首页</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/men">男装</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/women">女装</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/underwear">内衣</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/shoes">鞋履</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/sports">运动/户外</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/bag">箱包/礼品</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/jewelry">钟表首饰</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/kids">孕婴童</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/living">居家</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/cosmetic">美妆</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/children">童书</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/book">图书</a></li>
                          <li><a name="nav2" target="_blank" href="http://v.dangdang.com/global">国际名品</a></li>
              </ul>
  </div>    </div>
      <div class="v_nav_sbox"><div class="v_nav_sbox_inner">
          <div id="search_content_2" class="search_box"></div>
      </div></div>
  </div>
</div>



<style type="text/css">
  .footer_w {margin-top:0;}
  .tg-nav {overflow:hidden;}
  .tg-nav-menu {float: right; width: 240px; background: #fff; padding-left: 10px; padding-right: 10px; padding-top: 1em;padding-bottom: 1000em;
margin-bottom: -1000em;}
  .member {
margin-bottom: 22px;

}
  .member h3 {font-size: 18px;
color: #06c;
font-weight: normal;
line-height: 1;
background: url(http://www.wetcode.com.cn/templates/mima/images/search-icon.png) 0 0px no-repeat;
height: 22px;
line-height: 22px;
background-size: 16px auto;
padding-left: 20px;
}
  .member h3 span {padding-right: 15px;}
  .server-box-ct a {margin-left: -1px;
text-decoration: none;
background: #fff;
border: 0;
color: #D22C00;
padding: 0 10px;
float: left;
width: 41px;
overflow: hidden;
margin-bottom: 5px;}
.member {clear:both; overflow:hidden;}
.tg-nav-link {float:left; width:910px; padding-bottom:20px; padding-top:1em; margin-left:0px; padding-left:10px;padding-right:10px;padding-bottom:10px; background:#fff;}
.two_line{
	position: relative;
	margin-top: 6px;
  width:237px;
  margin-bottom:12px;
}

.short_line{
	position:relative;
	width: 128px;
	height: 2px;
	background: #3098f9;
}

.less_short_line{
	position:relative;
	width: 105px;
	height: 2px;
	background: #06c;
}
.long_line{
	position:relative;
	width: 100%;
	height: 1px;
	background: #dddddd;
	margin-top: -3px;
}

.registbt {
display: inline-block;
text-align: center;
color: #fff;
text-shadow: 1px 1px 1px #444;
background: #0D8EE8;
background-image: -webkit-gradient(linear,0% 0%, 0% 100%, from(#0EAEEA), to(#06c), color-stop(1.0,#336600));
background-image: -moz-linear-gradient(0% 0% 270deg, #0EAEEA,#06c, #06c 100%);
background-image: -ms-linear-gradient(top, #0EAEEA, #06c);
box-shadow: 2px 2px 0px #c7ccd3;

padding: 9px 13px;
float: right;
font-size: 16px;
position: relative;
top: -16px;
border-radius:5px;

}
.wrap-tg-nav {background: rgba(48, 152, 249, 0.14); padding-top: 1em; padding-bottom: 1em;}
</style>
<div class="wrap-tg-nav">
  <div class="tg-nav w1020">
      <div class="tg-nav-menu" id="nav-menu">
        
                <div class="member listsc">
        <h3><span>商家位置</span></h3>
        <div class="two_line">
              <div class="less_short_line"></div>
              <div class="long_line"></div>
          </div>
        <div id="smimglist-warp">
          <img src="http://localhost/my-temp/website/des-water/qqpng.png" alt="" />
        </div>
        </div>

<style type="text/css">
.midas-wrap-shop {
    margin-top:10px
}
.midas-wrap-shop .title {
    padding-top:10px;
    border-bottom:1px solid #ececec
}
.midas-wrap-shop .title h4 {
    float:left;
    margin-bottom:-1px;
    padding-bottom:10px;
    border-bottom:2px solid #f63
}
.midas-wrap-shop .title .logo {
    top:7px
}
.midas-wrap-shop .mn li {
    margin-top:6px
}
.midas-wrap-shop .mn .img-shop img {
    width:240px;
    height:179px
}
.midas-wrap-shop .mn-lr {
    position:relative;
    height:69px;
    padding:15px 0 0 100px
}
.midas-wrap-shop .mn-lr .tit {
    font-size:14px
}
.midas-wrap-shop .mn-lr .tit .icon {
    margin-left:5px
}
.midas-wrap-shop .mn-lr .img-shop {
    position:absolute;
    top:15px;
    left:0
}
.midas-wrap-shop .mn-lr .img-shop img {
    width:93px;
    height:69px
}
.midas-wrap-shop .mn-lr .star {
    margin-top:8px
}
.midas-wrap-shop .mn-lr .info {
    margin-top:10px;
    color:#999
}
.midas-wrap-shop .coupon {
    border-top:1px dashed #eee
}
.midas-wrap-shop .coupon .con {
    position:relative;
    height:90px;
    padding:10px 0 0 100px
}
.midas-wrap-shop .coupon .con .img-coupon {
    position:absolute;
    top:10px;
    left:0
}
.midas-wrap-shop .coupon .con .img-coupon img {
    width:90px;
    height:90px
}
.midas-wrap-shop .coupon .con .expire {
    color:#999;
    line-height:22px;
    text-align:right
}
.midas-wrap-shop .coupon .more {
    margin-top:10px
}
.midas-wrap-shop .review {
    margin-top:5px
}
.midas-wrap-shop .review a {
    font-size:12px;
    display:block;
    word-wrap:break-word;
    word-break:break-all;
    line-height:22px
}
.midas-wrap-shop .review a:hover {
    color:#f63
}
</style>
        
                <div class="member listsc">
        <h3><span>相关商品</span></h3>
        <div class="two_line">
              <div class="less_short_line"></div>
              <div class="long_line"></div>
          </div>
        <div id="itemblock" class="midas-wrap-shop">
          <div class="J_con"><div class="item" data-midas="ad=10018656&amp;slot=4&amp;adidx=0" data-viewed="true" data-click-inited="true" data-midas-impressed="true"><div class="mn-lr"><a href="/shop/17627416" target="_blank" class="img-shop" onclick="document.hippo.mv('ad_c','10018656_74');" data-midas-extends="module=6_cpm_shop_pic"><img src="http://p1.s1.dpfile.com/pc/ed969eb023f34fa1806a8e4b93c251af(240x180)/thumb.jpg" alt="百丈园"></a><p class="tit"><a href="/shop/17627416" target="_blank" title="百丈园" onclick="document.hippo.mv('ad_c','10018656_74');" data-midas-extends="module=6_cpm_shop_name">百丈园</a><a href="/shop/17627416" target="_blank" class="icon tag-tuan-s" onclick="document.hippo.mv('ad_c','10018656_74');" data-midas-extends="module=6_cpm_icon_tuan"></a></p><p class="star"><span class="sml-rank-stars sml-str35"></span></p><p class="info"><span class="fr">人均 ¥81</span><span class="region">天河区</span></p></div></div><div class="item" data-midas="ad=10009842&amp;slot=4&amp;adidx=1" data-viewed="true" data-click-inited="true" data-midas-impressed="true"><div class="mn-lr"><a href="/shop/3500059" target="_blank" class="img-shop" onclick="document.hippo.mv('ad_c','10009842_74');" data-midas-extends="module=6_cpm_shop_pic"><img src="http://p3.s1.dpfile.com/pc/e81feef96f5491524070aabf01476fb2(240x180)/thumb.jpg" alt="麓苑轩酒家（蒸汽火锅）"></a><p class="tit"><a href="/shop/3500059" target="_blank" title="麓苑轩酒家（蒸汽火锅）" onclick="document.hippo.mv('ad_c','10009842_74');" data-midas-extends="module=6_cpm_shop_name">麓苑轩酒家（...</a><a href="/shop/3500059" target="_blank" class="icon tag-cu-s" onclick="document.hippo.mv('ad_c','10009842_74');" data-midas-extends="module=6_cpm_icon_coupon"></a><a href="/shop/3500059" target="_blank" class="icon tag-tuan-s" onclick="document.hippo.mv('ad_c','10009842_74');" data-midas-extends="module=6_cpm_icon_tuan"></a></p><p class="star"><span class="sml-rank-stars sml-str45"></span></p><p class="info"><span class="fr">人均 ¥62</span><span class="region">越秀区</span></p></div></div><div class="item" data-midas="ad=10003594&amp;slot=4&amp;adidx=2" data-viewed="true" data-click-inited="true" data-midas-impressed="true"><div class="mn-lr"><a href="/shop/5533764" target="_blank" class="img-shop" onclick="document.hippo.mv('ad_c','10003594_74');" data-midas-extends="module=6_cpm_shop_pic"><img src="http://i3.dpfile.com/pc/3868473f0a1bd68182fa4372866bc4ac(240x180)/thumb.jpg" alt="源德顺酒家"></a><p class="tit"><a href="/shop/5533764" target="_blank" title="源德顺酒家" onclick="document.hippo.mv('ad_c','10003594_74');" data-midas-extends="module=6_cpm_shop_name">源德顺酒家</a></p><p class="star"><span class="sml-rank-stars sml-str30"></span></p><p class="info"><span class="fr">人均 ¥47</span><span class="region">越秀区</span></p></div></div></div>
        </div>
        </div>



        <div class="member listsc">
        <h3><span>最新活动</span></h3>
        <div class="two_line">
              <div class="less_short_line"></div>
              <div class="long_line"></div>
          </div>
        <div id="smimglist-warp"><ul class="smimglist" >
  
        <li><a href="http://mall.bydauto.com.cn/xian/index/byd201415buy"> <img src="http://mall.bydauto.com.cn/media/wysiwyg/1215/_237x255.jpg" alt=""></a></li>
  
        </ul></div>
        </div>
        <div class="member listsc">
        <h3><span>扫一扫</span></h3>
        <div class="two_line">
              <div class="less_short_line"></div>
              <div class="long_line"></div>
          </div>
        <div id="smimglist-warp"><ul class="smimglist">
  
        <li><a href="http://mall.bydauto.com.cn/xian/index/byd201415buy"> <img src="http://img01.taobaocdn.com/imgextra/i1/1114455927/T2KMLjXgBaXXXXXXXX_!!1114455927.png" alt="" width="240"></a></li>
  
        </ul></div>
        </div>
  
        
  
  
      </div>

      <style type="text/css">
        .basic-info {
    position:relative;
   
    
    background-color:#fff;
   
   
    _zoom:1;
    _margin:0
}
.basic-info.default {
    border-right:none;

}
.basic-info .cover {
    display:block;
    width:5px;
    position:absolute;
    background-color:#fff;
    top:0;
    bottom:0;
    right:-4px;
    z-index:10
}
.basic-info .icon {
    display:inline-block;
    vertical-align:middle;
    _overflow:hidden
}
.basic-info .shop-name {
  font-size: 22px;
  margin-top: -7.5px;
  padding-bottom: 5px;
  line-height: 30px;
}
.basic-info .shop-name .v-shop {
    width:19px;
    height:19px;
    background-position:-100px -60px;
    margin-left:3px;
    vertical-align:-1px
}
.basic-info .shop-name .branch {
    float:right;
    font-size:12px;
    margin-top:2px;
    text-decoration:none
}
.basic-info .shop-name .i-arrow {
    width:8px;
    height:4px;
    background-position:-100px -90px;
    margin-left:5px
}
.basic-info .brief-info {
    margin-top:6px;
    font-size:14px;
    color:#ebebeb
}
.basic-info .brief-info .shop-star {
    margin-bottom:5px
}
.basic-info .brief-info .shop-star .mid-rank-stars {
    vertical-align:-3px;
    _vertical-align:middle;
    _margin-top:6px;
    _margin-bottom:6px
}
.basic-info .brief-info .item {
    margin:0 10px;
    vertical-align:middle;
    color:#999
}
.basic-info .brief-info .score-btn {
    width:16px;
    height:15px;
    background-position:-60px -60px
}
.basic-info .star-from {
    width:16px;
    height:16px;
    background-position:-140px -90px;
    cursor:pointer
}
.basic-info .star-from:hover {
    background-position:-160px -90px
}
.basic-info .expand-info {
    font-size:14px;
    color:#282828;
    margin-top:9px
}
.basic-info .expand-info.tel {
    margin-top:6px
}
.basic-info .expand-info.address {
    margin-top:7px;
    height:28px;
    line-height:28px
}
.basic-info .expand-info.address .item {
    max-width:350px;
    overflow:hidden;
    white-space:nowrap;
    -o-text-overflow:ellipsis;
    text-overflow:ellipsis;
    display:inline-block;
    vertical-align:top;
    _vertical-align:middle
}
.basic-info .expand-info.address .item-gray {
    max-width:200px;
    overflow:hidden;
    white-space:nowrap;
    -o-text-overflow:ellipsis;
    text-overflow:ellipsis;
    display:inline-block;
    vertical-align:top;
    _vertical-align:middle
}
.basic-info .expand-info .tag {
    _margin-right:7px
}
.basic-info .expand-info .url-btn {
    display:inline-block;
    height:26px;
    line-height:26px;
    font-size:12px;
    margin-left:6px;
    padding:0 10px;
    border:1px solid #f4cea8;
    color:#ff8400;
    background-color:#fffcf5
}
.basic-info .expand-info .item-gray {
    color:#999;
    white-space:nowrap;
    margin-left:16px
}
.basic-info .expand-info .item-gray:hover {
    color:#f63
}
.basic-info .unfold, .basic-info .fold {
    color:#999;
    line-height:35px;
    text-decoration:none;
    display:block;
    margin-top:4px;
    width:100px
}
.basic-info .unfold .icon, .basic-info .fold .icon {
    width:12px;
    height:7px;
    margin-left:7px;
    _margin:14px 0 14px 5px
}
.basic-info .unfold:hover, .basic-info .fold:hover {
    color:#f63
}
.basic-info .unfold .icon {
    background-position:-140px -60px
}
.basic-info .unfold:hover .icon {
    background-position:-140px -70px
}
.basic-info .fold .icon {
    background-position:-160px -60px
}
.basic-info .fold:hover .icon {
    background-position:-160px -70px
}
.basic-info .other {
    font-size:12px;
    padding-bottom:10px;
    margin-top:-8px
}
.basic-info .other .info {
    margin-top:10px
}
.basic-info .other .info .item {
    margin-right:10px
}
.basic-info .other .info .division {
    color:#ebebeb
}
.basic-info .other .info .item-gray {
    color:#999;
    white-space:nowrap
}
.basic-info .other .info .item-gray:hover {
    color:#f63
}
.basic-info .other .info .multi-info {
    display:inline-block;
    vertical-align:top
}
.basic-info .other .i-afternoon, .basic-info .other .i-delivery, .basic-info .other .i-night-snack, .basic-info .other .i-twenty-four, .basic-info .other .i-park, .basic-info .other .i-afternoon-tea, .basic-info .other .i-breakfast {
    width:16px;
    height:16px;
    margin-right:5px;
    vertical-align:-3px;
    _vertical-align:middle;
    _margin:4px 5px 4px 0
}
.basic-info .other .i-afternoon {
    background-position:-140px -110px
}
.basic-info .other .i-delivery {
    background-position:-100px -110px
}
.basic-info .other .i-night-snack {
    background-position:-120px -110px
}
.basic-info .other .i-twenty-four {
    background-position:-20px -110px
}
.basic-info .other .i-park {
    background-position:-40px -110px
}
.basic-info .other .i-afternoon-tea {
    background-position:-80px -110px
}
.basic-info .other .i-breakfast {
    background-position:-160px -110px
}
.basic-info .other .i-arrow {
    width:8px;
    height:4px;
    background-position:-100px -90px;
    margin-left:5px
}
.basic-info .info-indent {
    position:relative;
    padding-left:70px;
    _zoom:1
}
.basic-info .info-indent .info-name {
    position:absolute;
    left:0;
    top:0;
    color:#282828
}
.basic-info .info-indent-2 {
    padding-left:47px
}
.basic-info .url-btn {
    display:inline-block;
    height:26px;
    line-height:26px;
    font-size:12px;
    padding:0 10px;
    border:1px solid #f4cea8;
    color:#ff8400;
    background-color:#fffcf5
}
.basic-info .shop-closed {
    position:absolute;
    left:0;
    bottom:5px;
    width:384px;
    height:36px;
    line-height:34px;
    font-size:14px;
    padding:5px 16px
}
.basic-info .shop-closed .icon {
    width:22px;
    height:19px;
    background-position:-120px -30px;
    margin-right:4px;
    vertical-align:-4px;
    _vertical-align:middle
}
.basic-info .shop-closed .status {
    color:#fa5e00;
    font-size:14px
}
.basic-info .shop-closed .reopen {
    display:inline-block;
    margin-left:12px;
    padding:0 18px;
    border:1px solid #ebebeb;
    -webkit-border-radius:3px;
    border-radius:3px
}
.basic-info .shop-closed .tmpclose-txt {
    font-weight:700;
    color:#fa5e00
}
.basic-info .shop-closed .refershop-txt {
    color:#fa5e00
}
.basic-info .action {
    left:15px;
    bottom:15px;
    right:15px;
    height:36px
}
.basic-info .action .act-mod {
    position:relative;
    display:block;
    margin-left:10px;
    width:186px;
    height:34px;
    _padding:10px 0 5px;
    _height:19px;
    line-height:34px;
    border:1px solid #ebebeb;
    float:left
}
.basic-info .action .act-mod:hover span {
    color:#fa5e00
}
.basic-info .action .act-mod .book {
    width:24px;
    height:20px;
    background-position:0 -60px;
    margin-left:10px;
    margin-right:6px
}
.basic-info .action .act-mod .out {
    width:25px;
    height:18px;
    background-position:-107px -129px;
    margin-left:10px;
    margin-right:6px;
    vertical-align:-4px
}
.basic-info .action .act-mod .hd {
    font-size:14px;
    margin-right:6px
}
.basic-info .action .act-mod .desc {
    color:#999
}
.basic-info .action .act-mod .hot {
    display:inline-block;
    overflow:hidden;
    width:27px;
    height:13px;
    background-position:0 -130px;
    position:absolute;
    right:-2px;
    top:-4px
}
.basic-info .action .act-mod .new {
    background-position:-30px -130px;
    display:inline-block;
    overflow:hidden;
    width:27px;
    height:13px;
    position:absolute;
    right:-2px;
    top:-4px
}
.basic-info .action .left-action {
    float:left
}
.basic-info .action .right-action {
    float:right;
    margin-top:5px;
    margin-right:5px;
    z-index:30
}
.basic-info .action .write {
    padding:0 15px;
    height:36px;
    line-height:36px;
    font-size:14px;
    color:#fff;
    background-color:#ff7200;
    -webkit-border-radius:3px;
    border-radius:3px
}
.basic-info .action .write:hover {
    background-color:#fa5e00;
    color:#fff
}
.basic-info .action .write .icon {
    width:25px;
    height:20px;
    background-position:-30px 0;
    margin-right:6px;
    _margin:7px 6px 8px 0
}
.basic-info .action .share, .basic-info .action .favorite, .basic-info .action .favorited, .basic-info .action .report, .basic-info .action .action-more {
    line-height:24px;
    padding:1px 6px;
    margin-top:5px
}
.basic-info .action .share .icon {
    width:20px;
    height:19px;
    background-position:-60px 0
}
.basic-info .action .share:hover .icon {
    background-position:-60px -30px
}
.basic-info .action .favorite .icon, .basic-info .action .favorited .icon {
    width:20px;
    height:20px;
    background-position:-90px 0
}
.basic-info .action .favorite:hover .icon, .basic-info .action .favorited:hover .icon {
    background-position:-90px -30px
}
.basic-info .action .favorited .icon {
    background-position:-90px -30px
}
.basic-info .action .report .icon {
    width:22px;
    height:19px;
    background-position:-120px 0
}
.basic-info .action .report:hover .icon {
    background-position:-120px -30px
}
.basic-info .action .action-more {
    line-height:24px
}
.basic-info .action .action-more .icon {
    width:17px;
    height:3px;
    background-position:-150px 0
}
.basic-info .action .action-more:hover .icon {
    background-position:-150px -30px
}
.basic-info .action .active {
    line-height:24px;
    margin-top:-3px;
    display:inline-block;
    position:relative;
    padding:0 5px;
    border:1px solid #ebebeb;
    border-bottom:none;
    background-color:#fff;
    -webkit-border-radius:2px 2px 0 0;
    border-radius:2px 2px 0 0;
    z-index:1
}
    .picoprolist {text-align:center;}
    .picoprolist .item {padding:0 10px; display:inline-block;}
    .picoprolist .item img {border:1px solid #ddd;
    }

    .branch {float: right; display: inline-block; margin-top: 10px;}
      
      </style>

      <div class="tg-nav-link" id="nav-link">
        <div id="basic-info" class="basic-info default nug_shop_ab_pv-a">
<s class="cover J_cover"></s>
<h1 class="shop-name">

    
    
</h1>
<div class="mod">
      <h1 class="mod-title">
              <a class="item current"  style="font-size:28px;height: 38px;font-weight:bold;color:#333;">和苑酒家<a class="branch J-branch">其它1家分店<i class="icon i-arrow"></i></a></a>
          </h1>
    </div>

<div class="brief-info">
    <span title="五星商户" class="mid-rank-stars mid-str50"></span>
        <span class="item">797条评论</span>
    
    <span class="item">人均：105元</span>
    |
        <span class="item">口味：9.0</span>
|
        <span class="item">环境：9.1</span>
|
        <span class="item">服务：9.1</span>
        <a class="icon score-btn J-score"></a>
</div>
<div class="expand-info address" itemprop="street-address">
    <span class="info-name">地址：</span>
<a href="/search/category/4/10/r24" rel="nofollow" target="_blank">
    <span itemprop="locality region">越秀区</span></a>
    <span class="item" itemprop="street-address" title="东风中路481号粤财大厦3-4楼(近正骨医院)">
    东风中路481号粤财大厦3-4楼(近正骨医院)
    </span>
</div>
<p class="expand-info tel">
    <span class="info-name">电话：</span>
        <span class="item" itemprop="tel">020-83063668</span>
        <span class="item" itemprop="tel">020-83063500</span>
</p>
<p class="expand-info J-service nug-shop-ab-special_a">
    <span class="info-name">特色：</span>
    <a class="tag tag-tuan-b J-service-tuan" href="http://t.dianping.com/deal/2189031" target="_blank">团购</a>
	
	
	
	
	
	
    
	
</p>
<p class="expand-info J-service nug-shop-ab-special_a">相关图片:</p>
<div class="picoprolist">
  <div class="item">
    <img src="http://i3.dpfile.com/pc/9d99ef93e1b31b1854e320f6f81ad0f9/36861503_m.jpg" alt="" />
  </div>
  <div class="item">
    <img src="http://i3.dpfile.com/pc/9d99ef93e1b31b1854e320f6f81ad0f9/36861503_m.jpg" alt="" />
  </div>
  <div class="item">
    <img src="http://i3.dpfile.com/pc/9d99ef93e1b31b1854e320f6f81ad0f9/36861503_m.jpg" alt="" />
  </div>
</div>
<a class="J-unfold unfold">更多信息<i class="icon"></i></a>
<div class="other J-other ">
    <p class="info info-indent">

        <span class="info-name">营业时间：</span>
                <span class="item">
                    茶市：9:30 - 14:30节假日 11:00 - 14:30平时
                </span>
        <a class="item-gray J-edit-time">
            修改
        </a>
    </p>

    <p class="info J-feature Hide"></p>

    <p id="park" class="info info-indent J-park"><span class="info-name">停车信息：</span><a class="J-stop">由34位用户提供</a></p>


        <p class="info info-indent">
            <span class="info-name">分类标签：</span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E5%8F%AF%E4%BB%A5%E5%88%B7%E5%8D%A1" rel="tag" target="_blank">可以刷卡</a>(144)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E5%95%86%E5%8A%A1%E5%AE%B4%E8%AF%B7" rel="tag" target="_blank">商务宴请</a>(110)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E5%AE%B6%E5%BA%AD%E8%81%9A%E4%BC%9A" rel="tag" target="_blank">家庭聚会</a>(84)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E5%85%8D%E8%B4%B9%E5%81%9C%E8%BD%A6" rel="tag" target="_blank">免费停车</a>(73)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E6%9C%8B%E5%8F%8B%E8%81%9A%E9%A4%90" rel="tag" target="_blank">朋友聚餐</a>(72)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E6%97%A0%E7%BA%BF%E4%B8%8A%E7%BD%91" rel="tag" target="_blank">无线上网</a>(37)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E6%83%85%E4%BE%A3%E7%BA%A6%E4%BC%9A" rel="tag" target="_blank">情侣约会</a>(23)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E4%BE%9B%E5%BA%94%E6%97%A9%E9%A4%90" rel="tag" target="_blank">供应早餐</a>(22)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E6%9C%89%E4%B8%8B%E5%8D%88%E8%8C%B6" rel="tag" target="_blank">有下午茶</a>(14)
                        </span>
                <span class="item">
                    <a href="/search/keyword/4/10_%E4%BC%91%E9%97%B2%E5%B0%8F%E6%86%A9" rel="tag" target="_blank">休闲小憩</a>(10)
                        </span>
        </p>


    <p class="info info-indent J-Contribution">		<span class="info-name">会员贡献：</span>        <span class="multi-info multi-sp">	        	        	<span class="item multi-item">	                <a target="_blank" rel="nofollow" href="/member/2878816" title="milaco">	                	milaco	                </a>	                添加商户	            </span>	        	        <span class="item-gray item">|</span>	        	        	<span class="item multi-item">	                <a target="_blank" rel="nofollow" href="/review/20445562" title="懶懶懶懶懶死">懶懶懶懶懶死</a>发布首条点评	            </span>	            <span class="item-gray item">|</span>	        	        <span class="multi-item">	        			        	<span class="item-sp item">系统在2014-02-13最后更新</span>		        		        		        	<a class="item-gray" target="_blank" rel="nofollow" href="/shop/3687997/editmember">详情</a>		        	        </span>	    </span></p>
</div>

<div class="action">
    <a class="write left-action" href="/shop/3687997/review" target="_blank" rel="nofollow">写点评</a>




    <span class="right-action">
                <a class="share J-weixin" rel="nofollow" title="微信分享"><i class="icon"></i></a>
                <a id="fav" class="favorite J-favorite" rel="nofollow" title="收藏"><i class="icon"></i></a>
                <a class="report" title="报错" href="/shop/3687997/edit" rel="nofollow" target="_blank"><i class="icon"></i></a>
                <a class="action-more J-action-more"><i class="icon"></i></a>
                
            </span>
</div>
<style type="text/css">
  .body .aside {
    float:left;
    width:240px;
    padding-left:20px
}
.body .mod {
    margin-top:20px
}
.body .mod .mod-title {
    position:relative;
    border-bottom:1px solid #ebebeb;
    _zoom:1
}
.body .mod .mod-title .item {
    display:inline-block;
    height:30px;
    line-height:30px;
    font-size:14px;
    margin-right:15px;
    text-decoration:none
}
.body .mod .mod-title .current {
    border-bottom:2px solid #fa5e00;
    margin-bottom:-2px;
    cursor:default
}
.body .mod .mod-title .current:hover {
    color:#282828
}
.body .mod .mod-title .sub-title {
    color:#999
}
.body .mod .mod-title .more {
    position:absolute;
    right:0;
    top:0;
    font-size:12px;
    line-height:30px
}
.body .shop-owner .mod-content {
    margin-top:10px;
    font-size:14px
}
.body .shop-owner .mod-content .highlight {
    color:#fa5e00
}
.shop-data-info {
    font-size:14px;
    padding:25px 0;
    border-bottom:1px solid #ebebeb
}
.weixin-business-box {
    position:absolute;
    padding:46px 20px 37px 176px;
    border:1px solid #ebebeb;
    background-color:#fff;
    -webkit-box-shadow:1px 1px 2px rgba(0, 0, 0, .1);
    box-shadow:1px 1px 2px rgba(0, 0, 0, .1);
    _zoom:1
}
.weixin-business-box img {
    position:absolute;
    left:8px;
    top:8px;
    width:156px;
    height:156px;
    margin-right:12px
}
.weixin-business-box p {
    line-height:22px;
    white-space:nowrap
}
.weixin-business-box .icon {
    _overflow:hidden;
    position:absolute;
    left:45px;
    bottom:-9px;
    width:15px;
    height:9px;
    margin-left:-7px;
    background-position:-60px -140px
}
.sales-promotion .icon {
    display:inline-block;
    vertical-align:middle;
    _overflow:hidden
}
.sales-promotion .mod-title {
    margin-bottom:15px
}
.sales-promotion .tag {
    display:inline-block;
    width:25px;
    height:25px;
    line-height:25px;
    vertical-align:middle;
    text-align:center;
    font-size:16px;
    color:#fff
}
.sales-promotion .tag-tuan {
    background-color:#f63
}
.sales-promotion .tag-cu {
    background-color:#ffa21d
}
.sales-promotion .tag-ka {
    background-color:#4ea3d4
}
.sales-promotion .tag-ding {
    background-color:#5eb22d
}
.sales-promotion .tag-guo {
    background-color:#f63
}
.sales-promotion .tag-huo {
    background-color:#ca92df
}
.sales-promotion .tag-wai {
    background-color:#46babb
}
.sales-promotion .group {
    margin-right:-20px;
    margin-top:10px;
    clear:both
}
.sales-promotion .group .item {
    position:relative;
    float:left;
    width:328px;
    border:1px solid #ebebeb;
    margin-right:20px;
    margin-top:-1px
}
.sales-promotion .group .big {
    padding:10px 10px 10px 102px;
    width:216px;
    height:47px
}
.sales-promotion .group .big .i-vshop {
    width:15px;
    height:15px;
    background-position:-80px -90px;
    margin-left:5px;
    vertical-align:-3px;
    _vertical-align:middle
}
.sales-promotion .group .big .title {
    font-size:14px;
    margin-bottom:-3px;
    white-space:nowrap;
    overflow:hidden;
    -o-text-overflow:ellipsis;
    text-overflow:ellipsis
}
.sales-promotion .group .big .pic {
    position:absolute;
    left:-1px;
    top:-1px;
    width:93px;
    height:69px;
    background-color:#ddd
}
.sales-promotion .group .big .price {
    display:inline-block;
    font-size:24px;
    color:#fa5e00;
    font-family:Microsoft YaHei, Hiragino Sans GB
}
.sales-promotion .group .big .price em {
    font-size:16px
}
.sales-promotion .group .big .del-price {
    display:inline-block;
    color:#999;
    font-family:Microsoft YaHei, Hiragino Sans GB
}
.sales-promotion .group .big .back {
    display:inline-block;
    color:#fa5e00;
    border:1px solid #ff7200;
    -webkit-border-radius:2px;
    border-radius:2px;
    padding:0 4px;
    height:16px;
    line-height:16px;
    font-size:12px;
    margin-left:7px;
    vertical-align:3px
}
.sales-promotion .group .big .tag {
    position:absolute;
    left:5px;
    top:5px
}
.sales-promotion .group .big .sold-count {
    position:absolute;
    right:10px;
    bottom:7px;
    font-size:12px;
    color:#999
}
.sales-promotion .group .big .block-link {
    position:absolute;
    left:-1px;
    top:-1px;
    border:2px solid #fa5e00;
    width:326px;
    height:65px;
    opacity:0;
    -ms-filter:"alpha(Opacity=0)";
    filter:alpha(opacity=0);
    -webkit-transition:opacity .3s ease-out;
    -moz-transition:opacity .3s ease-out;
    -o-transition:opacity .3s ease-out;
    -ms-transition:opacity .3s ease-out;
    transition:opacity .3s ease-out
}
.sales-promotion .group .big .block-link:hover {
    opacity:1;
    -ms-filter:none;
    filter:none
}
.sales-promotion .group .big-double {
    width:566px
}
.sales-promotion .group .big-double .block-link {
    width:676px
}
.sales-promotion .group .small {
    padding:5px 5px 5px 40px;
    width:283px;
    height:25px;
    font-size:14px;
    line-height:25px;
    overflow:hidden;
    text-decoration:none;
    white-space:nowrap;
    -o-text-overflow:ellipsis;
    text-overflow:ellipsis
}
.sales-promotion .group .small .tag {
    position:absolute;
    left:5px;
    top:5px
}
.sales-promotion .group .small .price {
    color:#fa5e00;
    margin-right:5px;
    font-family:Microsoft YaHei, Hiragino Sans GB;
    font-size:16px;
    display:inline-block;
    vertical-align:-2px
}
.sales-promotion .group .small .del-price {
    font-size:12px;
    margin-right:10px;
    color:#999;
    font-family:Microsoft YaHei, Hiragino Sans GB;
    display:inline-block;
    vertical-align:-2px
}
.sales-promotion .group .small .desc {
    float:right;
    font-size:12px;
    color:#999
}
.sales-promotion .group .small-double {
    width:633px
}
.sales-promotion .unfold, .sales-promotion .fold {
    float:right;
    line-height:32px;
    text-decoration:none
}
.sales-promotion .unfold .icon, .sales-promotion .fold .icon {
    width:12px;
    height:7px;
    margin-left:5px;
    _margin:12px 0 12px 5px
}
.sales-promotion .unfold .icon {
    background-position:-140px -60px
}
.sales-promotion .unfold:hover .icon {
    background-position:-140px -70px
}
.sales-promotion .fold .icon {
    background-position:-160px -60px
}
.sales-promotion .fold:hover .icon {
    background-position:-160px -70px
}
.sales-promotion .ticket-booking {
    margin-top:10px;
    border:1px solid #ebebeb;
    clear:both
}
.sales-promotion .ticket-booking .title {
    position:relative;
    height:25px;
    line-height:25px;
    padding:4px 4px 4px 39px;
    font-size:14px;
    border-bottom:1px solid #ebebeb
}
.sales-promotion .ticket-booking .title .tag {
    position:absolute;
    left:4px;
    top:4px
}
.sales-promotion .ticket-booking .content {
    padding:9px 9px 9px 39px;
    font-size:14px;
    height:35px;
    line-height:35px
}
.sales-promotion .ticket-booking .booking-btn {
    float:right;
    height:35px;
    line-height:35px;
    padding:0 20px;
    font-size:12px;
    background-color:#ff7200;
    color:#fff;
    -webkit-border-radius:2px;
    border-radius:2px
}
.sales-promotion .ticket-booking .booking-btn:hover {
    background-color:#fa5e00
}
.sales-promotion .ticket-booking .booking-btn strong {
    font-size:21px;
    font-family:Microsoft YaHei, Hiragino Sans GB;
    margin-right:3px;
    vertical-align:-2px;
    _vertical-align:middle;
}

.mod-title .item {
display: inline-block;
height: 30px;
line-height: 30px;
font-size: 14px;
margin-right: 15px;
text-decoration: none;
color:#333;
}

.mod .mod-title {
position: relative;
border-bottom: 1px solid #ebebeb;
_zoom: 1;
}
.mod .mod-title .current {
border-bottom: 2px solid #06c;
margin-bottom: -2px;
cursor: default;
}
#sales {margin-top:20px;}
</style>
<div id="sales" class="mod sales-promotion clearfix">
    <h2 class="mod-title">
        <a class="item current">优惠促销</a>
    </h2>
        <div class="group clearfix">
                <div class="item big">
                    <p class="title">
                        8人干鲍套餐
                    </p>
                    <img class="pic" src="http://t1.s1.dpfile.com/pc/mc/254227040962f45d6f6af6dcbae52ad5(450c280)/thumb.jpg">
                    <span class="price"><em>¥</em>988</span>
                    <del class="del-price">¥1716</del>
                        <i class="back">返现1%</i>
                        <i class="tag tag-tuan">团</i>
                        <span class="sold-count">已售166</span>
                    <a class="block-link" href="http://t.dianping.com/deal/2189031" target="_blank"></a>
                </div>
                <div class="item big">
                    <p class="title">
                        8人龙虾套餐
                    </p>
                    <img class="pic" src="http://t1.s1.dpfile.com/pc/mc/a11f5f6f670e98d45be8365abc67098b(450c280)/thumb.jpg">
                    <span class="price"><em>¥</em>1388</span>
                    <del class="del-price">¥2081</del>
                        <i class="back">返现1%</i>
                        <i class="tag tag-tuan">团</i>
                        <span class="sold-count">已售30</span>
                    <a class="block-link" href="http://t.dianping.com/deal/2189034" target="_blank"></a>
                </div>
        </div>
</div>

<div id="sales" class="mod sales-promotion clearfix">
    <h2 class="mod-title">
        <a class="item current">评论</a>
    </h2>

</div>

<style type="text/css">
        .media-left {display: table-cell;
vertical-align: top;
padding-right: 10px;
}
.itemblock {padding-bottom:5px;}
.media-left, .media-right, .media-body {
display: table-cell;
vertical-align: top;
}
.media {margin-top:10px;  }
.media:first-child {margin-top:0;}
.media:last-child {margin-bottom:0;}
 .media-body  {font-size:12px; color: #4d4d4d;}
.media-heading {padding: 0 0 0;
font-size: 14px;
color: #3b8cb0;
font-weight: bold;
overflow: hidden;

line-height: 120%;
margin-bottom:10px;
}
.media-object {display:block;}
  .deal-list .deal-price {
  padding: 20px 0 10px;
  padding-top:0;
  padding-left:10px;
  padding-right:10px;
  }
.media-heading-lab {min-height:30px;}

.media {padding-bottom: 10px;
border-bottom: 0px solid #ddd;
margin-bottom: 10px;}

      </style>

<div class="itemblock">
      


          <div class="media">
        
      <a class="media-left" href="#">
        <img class="media-object" data-src="holder.js/64x64" alt="64x64" src="http://assets.alicdn.com/apps/mytaobao/3.0/profile/defaultAvatar/avatar-100.png" style="width: 64px; height: 64px;">
      </a>
      <div class="media-body">
        <h4 class="media-heading">
 广东移动100元官方快充 手机充值话费 移动全自动充值 即时到帐     </h4>
        <p class="media-heading-lab">【精工好料】:此款为进口PU皮，采用水洗工艺，仿真皮质感，防水防风，吸汗透气！【免费试穿】:支持先试后买，7天无理由退换货，全场赠运费险，购物无风险！</p>　
      <div class="media">
          <a class="media-left" href="#">
            <img class="media-object" data-src="holder.js/64x64" alt="64x64" src="http://assets.alicdn.com/apps/mytaobao/3.0/profile/defaultAvatar/avatar-100.png" data-holder-rendered="true" style="width: 64px; height: 64px;">
          </a>
          <div class="media-body">
            <h4 class="media-heading">广东移动100元官方快充 手机充值话费 移动全自动充值 即时到帐</h4>
            【精工好料】:此款为进口PU皮，采用水洗工艺，仿真皮质感，防水防风，吸汗透气！【免费试穿】:支持先试后买，7天无理由退换货，全场赠运费险，购物无风险！
          </div>
        </div>
        <div class="media">
          <a class="media-left" href="#">
            <img class="media-object" data-src="holder.js/64x64" alt="64x64" src="http://assets.alicdn.com/apps/mytaobao/3.0/profile/defaultAvatar/avatar-100.png" data-holder-rendered="true" style="width: 64px; height: 64px;">
          </a>
          <div class="media-body">
            <h4 class="media-heading">广东移动100元官方快充 手机充值话费 移动全自动充值 即时到帐</h4>
            【精工好料】:此款为进口PU皮，采用水洗工艺，仿真皮质感，防水防风，吸汗透气！【免费试穿】:支持先试后买，7天无理由退换货，全场赠运费险，购物无风险！
          </div>
        </div>
      </div>
</div>
<div class="media">
      <a class="media-left" href="#">
        <img class="media-object" data-src="holder.js/64x64" alt="64x64" src="http://assets.alicdn.com/apps/mytaobao/3.0/profile/defaultAvatar/avatar-100.png" style="width: 64px; height: 64px;">
      </a>
      <div class="media-body">
        <h4 class="media-heading">
 广东移动100元官方快充 手机充值话费 移动全自动充值 即时到帐     </h4>
        【精工好料】:此款为进口PU皮，采用水洗工艺，仿真皮质感，防水防风，吸汗透气！【免费试穿】:支持先试后买，7天无理由退换货，全场赠运费险，购物无风险！　
      </div>
    </div>


    </div>


</div>
      </div>
  </div>
</div>

<div class="footer_w" style="width:auto;"><div class="compay">
      <p class="Color7">©2003-2014 dianping.com, All Rights Reserved.　　本站发布的所有内容，未经许可，不得转载，详见<a rel="nofollow" class="G" href="http://www.dianping.com/aboutus/zhishichanquan.html">《知识产权声明》</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a rel="nofollow" class="G" href="http://www.dianping.com/aboutus/useragreement">《用户使用协议》</a></p>
      <p class="Color7">增值电信业务经营许可证：<a href="http://www.miitbeian.gov.cn" rel="nofollow" class="G" target="_blank">沪B2-20040012</a>　　互联网地图服务资质：乙测资字31202063</p>
     </div>
    </div>   

<textarea class="J_auto-load">&lt;p class="certify" data-target=".footer_w"&gt;
&lt;a target="_blank" rel="nofollow" href="http://www.sgs.gov.cn/lz/licenseLink.do?method=licenceView&amp;entyId=20130409145349858"&gt;&lt;img alt="上海工商" height="47" src="http://j1.s2.dpfile.com/s/res/gongshang.73ce6165acedcdd46fa558bcf59aa974.gif"&gt;&lt;/a&gt;
&lt;a target="_blank" rel="nofollow" href="http://www.zx110.org/"&gt;&lt;img alt="网络社会征信网" height="47" src="http://j1.s2.dpfile.com/s/res/zx110-1.4a2a9ace41739062a34095c9b8243f53.png"&gt;&lt;/a&gt;
&lt;a target="_blank" rel="nofollow" href="https://ss.knet.cn/verifyseal.dll?sn=e13112611010043591jyx3000000&amp;ct=df&amp;pa=0.6434873733669519"&gt;&lt;img alt="可信网站" height="47" src="http://i1.dpfile.com/cms/20140220/472415298750.jpg"&gt;&lt;/a&gt;
&lt;a target="_blank" rel="nofollow" href="http://www.itrust.org.cn/yz/pjwx.asp?wm=1754770773"&gt;&lt;img alt="AAA认证" height="47" src="http://j2.s2.dpfile.com/s/res/trust_org.a60b32383d8f65848924df40c74c0eb5.png"&gt;&lt;/a&gt;
&lt;a target="_blank" rel="nofollow" href="https://search.szfw.org/cert/l/CX20130122002127002203"&gt;&lt;img alt="诚信网站" height="47" src="http://j3.s2.dpfile.com/s/res/chengxin.1642bdf0c620c6255f03cd4f53dd7c23.png"&gt;&lt;/a&gt;
&lt;/p&gt;
</textarea>


	<script>
			var __loaderConfig={appBase:'s/j/app/',libBase:'lib/1.0/',server:'j{n}.s2.dpfile.com'};
	</script>
<script src="http://j3.s2.dpfile.com/combos/~hls~hippo3.min.js,~lib~1.0~neuron.min.js/50434988245e6a86b8b77d317da2db54,70cd7bac78d0a4ba2c4111f067c72939.js"></script>		<script>
			DP.data({cityEnName:'guangzhou'});
			DP.load('http://j3.s2.dpfile.com/x_x/version.min.v1419932922965.js');
				DP.require("Main::index-header/header");
		</script>
			<script></script>
<script>
        DP.data({
			cityCookie:true,
			'cityID':4,
			staticheader:true,
			domain:'.dianping.com',
			cityEnName:'guangzhou'
		});
        DP.require('Main::biz/mkt','Main::tg-content',{
            mod:'Index::city',
            config:{
                userID:0,
                ipadJSON:{cookieexp : 365,content : '<a target="_blank" onclick="pageTracker._trackPageview(\'dp_head_app_remind_click\');" class="ih-wrapper" href="http://t.dianping.com/events/weixin20140617/"><img src="http://i2.dpfile.com/cms/20131119/355385471250.jpg" class="icon" alt="手机团购更优惠！"><p><strong>100%送世界杯彩票</strong><br></p></a>',starttime : 1404125336323,endtime : 1404125336323},
                cityId: 4,
                shopType: 0
            }
        });
    </script>
    <script type="text/javascript" id="nugget" data-city="guangzhou" src="http://j2.s2.dpfile.com/s/j/app/main/nugget-neuron-client.min.09970d6cc4d53ba965d403f449140fb1.js"></script>
    <!--[if IE 9]><script>
        DP.require({mod:'Index::pinsite',config:{notifyIcon: 'http://j2.s2.dpfile.com/s/res/pintab/notify.13c068be14cfbe5f640874e7c4c5ede3.ico',dragIcon: 'http://j1.s2.dpfile.com/s/res/pintab/drag.c7537deb91fe66e52daa223a6eb1602b.png'}});
    </script><![endif]-->
    <script>
        DP.require('main::app-2d');

DP.require({
    mod:"main::mkt",
    config: {
        query: {
            pageId: 3,
            cityId: 4,
            shopType: 0,
            categoryId: 0
        },
        server: '/mkt/ajax/getNewItems',
        request_type: 'ajax'
    }
},{
	mod:"booking::mainbookingplugin",
	config:{
		cityId:4
	}
},{
    mod:"hotel::index/hotel-shortcut"
},{
	mod:"activity::vdperweekstarplugin",
	config:{
		cityId:4
	}
});

DP.require(
        {
            mod:"main::side-banner",
            config:{
                pic:"http://i2.dpfile.com/s/res/chaojituan-pre.png",
                link: "http://t.dianping.com/event/20140222?utm_source=zhuzhanindex",
                position:"right",
                duration:["2014-2-21","2014-2-24"]
            }
        }
);
DP.require(
        {
            mod:"main::side-banner",
            config:{
                pic:"http://i2.dpfile.com/s/res/chaojituan.png",
                link: "http://t.dianping.com/event/20140222?utm_source=zhuzhanindex",
                position:"right",
                duration:["2014-2-25","2014-2-28"]
            }
        }
);
</script>

<script type="text/javascript" id="cdn-perf-script" data-ifr="http://j2.s2.dpfile.com/lib/1.0/cdn-perf/iframe.2ad1574697742b639b50ca924b47f428.html" src="http://j1.s2.dpfile.com/lib/1.0/cdn-perf/perf.min.5dc00a48a535db198b21aa4d268118db.js"></script>

<script type="text/javascript">
    !function(a,b){"undefined"!=typeof module&&module.exports?module.exports=b():"function"==typeof define?define(b):this[a]=b()}("cookieMonster",function(){function b(a){for(var b=[],c=a.split("."),d=c.length,e=!0,f="",g=d-1;g>=0;g--)e?(f=c[g],e=!1):(f="."+f,f=c[g]+f),d-1>g&&(b.push(f),b.push("."+f));return b}function c(c){for(var d=b(window.location.host),e=0;e<d.length;e++)a.removeItem(c,"/",d[e])}function d(a){var b="http://114.80.165.63/broker-service/api/single?hs=200&ts="+(new Date).getTime()+"&tu=cookiemonster-www&d="+a;(new Image).src=b}var a={removeItem:function(a,b,c){return document.cookie=encodeURIComponent(a)+"=; expires=Thu, 01 Jan 1970 00:00:00 GMT"+(c?"; domain="+c:"")+(b?"; path="+b:""),!0},keys:function(){for(var a=document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g,"").split(/\s*(?:\=[^;]*)?;\s*/),b=0;b<a.length;b++)a[b]=decodeURIComponent(a[b]);return a}};return{initWithWhiteList:function(b){if(b&&0!=b.length){for(var e={},f=0;f<b.length;f++){var g=b[f];e[g.name]=g}var h=a.keys();if(h&&0!=h.length){for(var i=0,f=0;f<h.length;f++){var j=h[f],k=e[j];k&&window.location.host.indexOf(k.domain)>-1||(c(j),i++)}d(i)}}}}}),setTimeout(function(){cookieMonster.initWithWhiteList([{name:"__utma",domain:".dianping.com"},{name:"__utmb",domain:".dianping.com"},{name:"__utmc",domain:".dianping.com"},{name:"__utmz",domain:".dianping.com"},{name:"_hc.s",domain:".hls.dianping.com"},{name:"_hc.v",domain:".dianping.com"},{name:"cy",domain:".dianping.com"},{name:"cye",domain:".dianping.com"},{name:"dper",domain:".dianping.com"},{name:"ua",domain:".dianping.com"},{name:"hotelTime",domain:"www.dianping.com"},{name:"gemini",domain:"www.dianping.com"},{name:"m_rs",domain:"www.dianping.com"},{name:"_bltn",domain:".dianping.com"},{name:"qqJewel",domain:".dianping.com"}])},3e3);
</script>
<script type="text/javascript">
	DP.data({
			isLogin: false,
		needAjaxOutput : false,
		baseSearch: function(){function i(a){return a.replace(/^\s+|\s+$/g,j)}function k(){var a=encodeURIComponent,b=i(h().replace(l," ")).replace(/\//g,""),c=m(q),f=m(r),a=-1!==c.indexOf("{q}")?c.replace("{q}",a(b)):c+a(b),c=d.getAttribute("data-s-cityid"),e={"\u5f69\u5986\u9020\u578b":166};"1"===c?e={"\u5a5a\u5bb4":2736,"\u5a5a\u5bb4\u9152\u5e97":2736,"\u5a5a\u793c\u4f1a\u6240":2738,"\u5a5a\u7eb1\u6444\u5f71":163,"\u5a5a\u7eb1\u793c\u670d":162,"\u5a5a\u5e86\u516c\u53f8":167,"\u5a5a\u6212\u9996\u9970":191,"\u5f69\u5986\u9020\u578b":166}:
"2"===c&&(e={"\u5a5a\u7eb1\u6444\u5f71":163,"\u5a5a\u7eb1\u793c\u670d":162,"\u5a5a\u5e86\u516c\u53f8":167,"\u5a5a\u6212\u9996\u9970":191,"\u5f69\u5986\u9020\u578b":166});b?(f=e[b],g.location.href=-1!==["\u53ef\u9001\u5916\u5356","\u5916\u5356","\u9644\u8fd1\u5916\u5356","\u5916\u9001","\u5916\u5356\u7f51"].indexOf(b)&&"1"===c?"http://waimai.dianping.com":f?"/search/category/"+c+"/55/g"+f:a):f?g.location.href=f:d.focus();return!1}function h(){return d.value}function m(a){for(var b=n,c=b.length;c--;)a=
a.replace("{"+c+"}",b[c]);return a}var n=arguments,g=this,o=g.document,j="",l=/[\\<]+/g,d=o.getElementById("G_s"),e=o.getElementById("G_s-btn"),q=d.getAttribute("data-s-pattern"),r=d.getAttribute("data-s-epattern"),p=e.onclick;d.onfocus=function(){this.className="focus"};d.onblur=function(){i(h())||(this.className=j)};d.onkeydown=function(a){a=a||g.event;if(13===a.keyCode){var a=e,b;document.createEvent?(b=document.createEvent("HTMLEvents"),b.initEvent("click",!0,!0)):(b=document.createEventObject(),
b.eventType="click");b.eventName="click";document.createEvent?a.dispatchEvent(b):a.fireEvent("on"+b.eventType,b);return!1}};e.onclick=k;return{s:l,data:function(){n=arguments},val:function(a){h=a},submit:k}}(4,0),
		cityId:4
	});
</script>


<iframe height="0" width="0" src="http://j2.s2.dpfile.com/lib/1.0/cdn-perf/iframe.2ad1574697742b639b50ca924b47f428.html" style="position: absolute; top: -999em; left: -999em;"></iframe><ul class="search-suggest" style="visibility: hidden;"></ul><style>.tb_button {padding:1px;cursor:pointer;border-right: 1px solid #8b8b8b;border-left: 1px solid #FFF;border-bottom: 1px solid #fff;}.tb_button.hover {borer:2px outset #def; background-color: #f8f8f8 !important;}.ws_toolbar {z-index:100000} .ws_toolbar .ws_tb_btn {cursor:pointer;border:1px solid #555;padding:3px}   .tb_highlight{background-color:yellow} .tb_hide {visibility:hidden} .ws_toolbar img {padding:2px;margin:0px}</style></body></html>